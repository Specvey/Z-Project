import java.util.ArrayList;
import java.util.Scanner;

/**
 * Main.java
 * 
 * Execution du programme
 */
public class Main
{
	public static void main(String args[])
	{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Choisissez un pseudo : ");
		String pseudo = sc.next();
		
		System.out.println("\nBonjour "+pseudo+", bienvenue dans ce monde infesté de zombies !");
		System.out.println("Pour gagner, vous devez atteindre la case victoire |V|.");
		System.out.println("Si un zombie |Z| vous mange, vous avez perdu.");
		
		
		String stringNiveauDifficulte;
		do
		{
			System.out.println("Veuillez choisir une difficulté pour que la partie se lance !");		
			System.out.print("(1 pour facile, 2 pour normale et 3 pour difficile) ");
			stringNiveauDifficulte= sc.next();
		}while(!stringNiveauDifficulte.equals("1") && !stringNiveauDifficulte.equals("2") && !stringNiveauDifficulte.equals("3"));
		int niveauDifficulte=Integer.parseInt(stringNiveauDifficulte);
		
		System.out.println("\n\n\n");
		int nombreDeZombies=2;
		switch(niveauDifficulte)
		{
			case 1 : nombreDeZombies=6;System.out.println("Difficulté : Facile.\nLes zombies se déplacent aléatoirement. La partie s'annonce simple !");break;
			case 2 : nombreDeZombies=4;System.out.println("Difficulté : Normale.\nAttention, les zombies vous entendent. Déplacez-vous sans faire de bruit !");break;
			case 3 : nombreDeZombies=3;System.out.println("Difficulté : Difficile.\nLes zombies savent où vous êtes ! Fuyez !");break;
		}
		Carte c=new Carte();
		Joueur joueur=new Joueur(pseudo);
		Jeu jeu=new Jeu(c,joueur,nombreDeZombies,niveauDifficulte);
		
		jeu.jouer();
	}
}
