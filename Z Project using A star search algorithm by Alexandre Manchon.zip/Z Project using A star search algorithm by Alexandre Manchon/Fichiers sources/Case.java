/**
 * Case.java
 * 
 * L'ensemble des cases forme la carte
 */

public class Case
{
	private boolean vide;
	private char symbole;
	
	public Case(boolean vide)
	{
		this.vide = vide;
		if(vide)
		{
			symbole='_';
		}
		else
		{
			symbole='#';
		}
	}
	
	public Case(boolean vide, char symbole)
	{
		this.vide = vide;
		this.symbole = symbole;
	}

	public boolean isVide()
	{
		return vide;
	}

	public void setVide(boolean vide)
	{
		this.vide = vide;
		if(vide)
		{
			symbole='_';
		}
		else
		{
			symbole='#';
		}
	}
	
	public void setVide(boolean vide, char symbole)
	{
		this.vide = vide;
		if(vide)
		{
			this.symbole='_';
		}
		else
		{
			this.symbole=symbole;
		}
	}

	public char getSymbole()
	{
		return symbole;
	}

	public void setSymbole(char symbole)
	{
		this.symbole = symbole;
	}
	
	public String toString()
	{
		return ""+symbole;
	}
}
