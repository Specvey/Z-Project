/**
 * Carte.java
 *
 * Dans cette classe, on va générer manuellement le terrain
 */

public class Carte
{
	private int nbrLignes;
	private int nbrColonnes;

	private Case tableau[][];
	
	public Carte()
	{
		this.nbrLignes=20;
		this.nbrColonnes=30;
		tableau=new Case[nbrLignes][nbrColonnes];
		initCarte2();
	}
	
	public Carte(int nbrLignes, int nbrColonnes)
	{
		this.nbrLignes=nbrLignes;
		this.nbrColonnes=nbrColonnes;
		tableau=new Case[nbrLignes][nbrColonnes];
		initCarte2();
	}
	
	public void initCarte1()
	{
		if(nbrLignes==20 && nbrColonnes==30)
		{
			/**
			 * Tout d'abord, on initialise toutes les cases à vrai
			 * Puis on mettra à faux pour les obstacles
			 */
			for(int j=0;j<nbrLignes;j++)
			{
				for(int k=0;k<nbrColonnes;k++)
				{
					tableau[j][k]=new Case(true);
				}
			}
			
			
			int i=0;
			// mur horizontal
			int ligne=0;
			for(i=3;i<=7;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=18;i<=27;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=1;
			for(i=10;i<=15;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=4;
			for(i=3;i<=7;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=12;i<=14;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=17;i<=20;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=23;i<=27;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=6;
			for(i=27;i<=29;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=7;
			for(i=8;i<=12;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=9;
			for(i=3;i<=5;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=17;i<=20;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=23;i<=27;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=10;
			for(i=0;i<=2;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=12;
			for(i=2;i<=5;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=15;
			for(i=8;i<=10;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=13;i<=14;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=17;
			for(i=2;i<=8;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=14;i<=18;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=19;
			for(i=18;i<=20;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			
			// mur vertical
			int colonne=2;
			for(i=11;i<=14;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=3;
			for(i=7;i<=8;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=6;
			for(i=18;i<=19;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=7;
			for(i=1;i<=3;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=8;
			for(i=8;i<=10;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=14;i<=17;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=12;
			for(i=5;i<=7;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=17;
			for(i=7;i<=14;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=20;
			for(i=1;i<=6;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=12;i<=19;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=23;
			for(i=7;i<=9;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=24;
			for(i=10;i<=12;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=27;
			for(i=5;i<=10;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=13;i<=19;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			// obstacle
			tableau[1][27].setVide(false);
			tableau[2][10].setVide(false);
			tableau[13][23].setVide(false);
			tableau[14][24].setVide(false);
			tableau[15][13].setVide(false);
			tableau[16][14].setVide(false);
			tableau[18][18].setVide(false);
			tableau[19][23].setVide(false);
		}
		else
		{
			System.out.println("Dimension de la carte incorrecte pour cette génération de carte.");
		}
	}
	
	public void initCarte2()
	{
		if(nbrLignes==20 && nbrColonnes==30)
		{
			/**
			 * Tout d'abord, on initialise toutes les cases à vrai
			 * Puis on mettra à faux pour les obstacles
			 */
			for(int j=0;j<nbrLignes;j++)
			{
				for(int k=0;k<nbrColonnes;k++)
				{
					tableau[j][k]=new Case(true);
				}
			}
			
			
			int i=0;
			// mur horizontal
			int ligne=0;
			for(i=3;i<=7;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=22;i<=24;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=1;
			for(i=10;i<=15;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=2;
			for(i=21;i<=25;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=27;i<=29;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=4;
			for(i=3;i<=7;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=12;i<=14;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=17;i<=20;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=23;i<=27;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=6;
			for(i=27;i<=29;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=7;
			for(i=8;i<=12;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=9;
			for(i=4;i<=5;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=17;i<=20;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=23;i<=25;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=10;
			for(i=0;i<=2;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=11;
			for(i=10;i<=12;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=13;
			for(i=10;i<=13;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=12;
			for(i=2;i<=5;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=15;
			for(i=8;i<=10;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			for(i=13;i<=14;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			ligne=17;
			for(i=2;i<=4;i++)
			{
				tableau[ligne][i].setVide(false);
			}
			
			// mur vertical
			int colonne=2;
			for(i=12;i<=14;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=3;
			for(i=7;i<=8;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=6;
			for(i=17;i<=19;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=8;
			for(i=8;i<=10;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=14;i<=17;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=12;
			for(i=5;i<=7;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=17;
			for(i=9;i<=10;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=12;i<=14;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=20;
			for(i=1;i<=6;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=12;i<=14;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=18;i<=19;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=23;
			for(i=7;i<=9;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=24;
			for(i=10;i<=12;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			colonne=27;
			for(i=6;i<=10;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=13;i<=16;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			for(i=18;i<=19;i++)
			{
				tableau[i][colonne].setVide(false);
			}
			// obstacles
			tableau[0][18].setVide(false);
			tableau[1][1].setVide(false);
			tableau[2][1].setVide(false);
			tableau[2][2].setVide(false);
			tableau[1][27].setVide(false);
			tableau[2][10].setVide(false);
			tableau[7][17].setVide(false);
			tableau[8][15].setVide(false);
			tableau[9][14].setVide(false);
			tableau[10][13].setVide(false);
			tableau[10][16].setVide(false);
			tableau[11][15].setVide(false);
			tableau[12][14].setVide(false);
			tableau[13][23].setVide(false);
			tableau[13][26].setVide(false);
			tableau[14][24].setVide(false);
			tableau[15][13].setVide(false);
			tableau[15][22].setVide(false);
			tableau[16][14].setVide(false);
			tableau[16][21].setVide(false);
			tableau[17][6].setVide(false);
			tableau[17][8].setVide(false);
			tableau[17][12].setVide(false);
			tableau[17][16].setVide(false);
			tableau[17][18].setVide(false);
			tableau[18][11].setVide(false);
			tableau[18][14].setVide(false);
			tableau[18][18].setVide(false);
			tableau[18][27].setVide(false);
			tableau[19][20].setVide(false);
			tableau[19][23].setVide(false);
		}
		else
		{
			System.out.println("Dimension de la carte incorrecte pour cette génération de carte.");
		}
	}
	
	public int getNbrLignes()
	{
		return nbrLignes;
	}

	public void setNbrLignes(int nbrLignes)
	{
		this.nbrLignes = nbrLignes;
	}

	public int getNbrColonnes()
	{
		return nbrColonnes;
	}

	public void setNbrColonnes(int nbrColonnes)
	{
		this.nbrColonnes = nbrColonnes;
	}

	public Case getCase(int ligne, int colonne)
	{
		return tableau[ligne][colonne];
	}

	public void setCase(int ligne, int colonne, Case c)
	{
		tableau[ligne][colonne]=c;
	}
	
	public String toString()
	{
		String s="";
		for(int i=0;i<nbrLignes;i++)
		{
			for(int j=0;j<nbrColonnes;j++)
			{
				s+="|"+tableau[i][j].toString();
			}
			s+="|\n";
		}
		return s;
	}
	
	public boolean isCaseVide(int ligne, int colonne)
	{
		return tableau[ligne][colonne].isVide();
	}
	
}
