/**
 * Joueur.java
 * 
 * Le joueur est un personnage avec un pseudo et correspond au symbole J
 */

public class Joueur extends Personnage
{
	
	public Joueur(String pseudo)
	{
		super(pseudo,'J');
	}
	
	public Joueur(String pseudo, int ligne, int colonne)
	{
		super(pseudo,'J', ligne, colonne);
	}
}
