import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * IntelligenceArtificielle.java
 * 
 * Classe abstraite mère de IA1 IA2 et IA3 qui partagent certaines caractéristiques
 * 
 */

public abstract class IntelligenceArtificielle
{
	protected int nbrLignes;
	protected int nbrColonnes;
	/**
	 * graphe contient tous les noeuds
	 * on en a besoin pour réutiliser les noeuds dans ferme et ouvert
	 */
	protected Noeud graphe[][];
	protected ArrayList<Noeud> ferme;
	protected ArrayList<Noeud> ouvert;
	protected Joueur joueur;
	protected Carte carte;
	protected int ligneZombie;
	protected int colonneZombie;
	
	
	public IntelligenceArtificielle(Carte carte, Joueur joueur, int ligneZombie, int colonneZombie)
	{
		this.nbrLignes=carte.getNbrLignes();
		this.nbrColonnes=carte.getNbrColonnes();
		graphe=new Noeud[nbrLignes][nbrColonnes];
		ferme=new ArrayList<Noeud>();
		ouvert=new ArrayList<Noeud>();
		this.joueur=joueur;
		this.carte=carte;
		this.ligneZombie=ligneZombie;
		this.colonneZombie=colonneZombie;
		initGraphe();
		
	}
	
	public void initGraphe()
	{
		/**
		 * pour chaque coordonées valides, on crée un noeud
		 */
		
		for(int i=0;i<nbrLignes;i++)
		{
			for(int j=0;j<nbrColonnes;j++)
			{
				if(carte.isCaseVide(i,j))
				{
					graphe[i][j]=new Noeud(i,j);
				}
			}
		}
	}
	
	public abstract boolean algoRecherche();
	public abstract char rechercheDirection();
	
	
	
	/**
	 * Le meilleur résultat d'une heuristique est 0.
	 */
	
	/**
	 * l'heuristique :
		f(n)=profondeur(n)+h(n)
		profondeur(n) la longueur du chemin entre la racine et n
		h(n) est la partie heuristique, elle doit être la plus informée possible
	 */
	
	
	/**
	 * distance entre le zombie et le joueur en niant l'existance des obstacles
	 */
	public double distanceJoueur(Noeud n)
	{
		return Math.abs(n.getLigne()-joueur.getLigne())+Math.abs(n.getColonne()-joueur.getColonne());
	}
	
	/**
	 * Méthode qui tri une liste de noeud par ordre croissant de son heuristique
	 */
	public void tri(ArrayList<Noeud> liste)
	{
		Collections.sort(liste, new Comparator<Noeud>(){
			public int compare(Noeud n1, Noeud n2)
			{
				if(n1.getHeuristique().compareTo(n2.getHeuristique()) == 1)
				{
					return 1;
				}
				else if(n1.getHeuristique().compareTo(n2.getHeuristique()) == -1)
				{
					return -1;        	
				}
				else
				{
					return 0;
				}
			}
		});
	}
	
	public void listerFils(Noeud n)
	{
		int ligneNoeud=n.getLigne();
		int colonneNoeud=n.getColonne();
		
		// en haut
		if(ligneNoeud-1 >=0 && carte.isCaseVide(ligneNoeud-1, colonneNoeud))
		{
			n.addFils(graphe[ligneNoeud-1][colonneNoeud]);
		}
		
		// à gauche
		if(colonneNoeud-1 >=0 && carte.isCaseVide(ligneNoeud, colonneNoeud-1))
		{
			n.addFils(graphe[ligneNoeud][colonneNoeud-1]);
		}
		
		// en bas
		if(ligneNoeud+1 < nbrLignes && carte.isCaseVide(ligneNoeud+1, colonneNoeud))
		{
			n.addFils(graphe[ligneNoeud+1][colonneNoeud]);
		}
		
		// à droite
		if(colonneNoeud+1 < nbrColonnes && carte.isCaseVide(ligneNoeud, colonneNoeud+1))
		{
			n.addFils(graphe[ligneNoeud][colonneNoeud+1]);
		}
	}
	
	
	public void printFerme()
	{
		String s="";
		for(Noeud n:ferme)
		{
			s+=n.toString()+"\n";
		}
		System.out.println(s);
	}
	
	public void printOuvert()
	{
		String s="";
		for(Noeud n:ouvert)
		{
			s+=n.toString()+"\n";
		}
		System.out.println(s);
	}
}

