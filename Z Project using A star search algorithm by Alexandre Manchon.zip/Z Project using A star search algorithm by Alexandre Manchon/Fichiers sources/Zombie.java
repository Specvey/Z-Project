/**
 * Zombie.java
 * 
 * Un zombie est un personnage doté d'une intelligence artificielle.
 * Un zombie est représenté par un Z sur la carte.
 * 
 */

public class Zombie extends Personnage
{
	private IntelligenceArtificielle IA;
	
	public Zombie(int ligne, int colonne)
	{
		super("Zombie",'Z', ligne, colonne);
	}
	
	/**
	 * fait appel à l'IntelligenceArtificielle qui va chercher le meilleur chemin pour le zombie
	 * s'il doit aller en haut renvoie 'z', à gauche 'q', en bas 'd' et à droite 'd'
	 */
	public char nextMove(Carte carte, Joueur joueur, int niveauDifficulte)
	{
		switch(niveauDifficulte)
		{
			case 1:IA=new IA1(carte,joueur,getLigne(),getColonne());break;
			case 2:IA=new IA2(carte,joueur,getLigne(),getColonne());break;
			case 3:IA=new IA3(carte,joueur,getLigne(),getColonne());break;
		}
		boolean joueurTrouve=IA.algoRecherche();
		if(!joueurTrouve)
		{
			// L'algorithme de recherche n'a pas trouvé le joueur
			return ' ';
		}
		else
		{
			char direction=IA.rechercheDirection();
			if(direction!='z' && direction!='q' && direction!='s' && direction!='d')
			{
				System.err.println("ERREUR : La direction n'a pas été trouvé");
				return ' ';
			}
			else
			{
				return direction;
			}
		}
		
	}
}
