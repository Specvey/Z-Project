import java.util.Scanner;

/**
 * Jeu.java
 * 
 * L'évolution d'une partie, tour par tour.
 */

public class Jeu
{
	private Carte carte;
	private Joueur joueur;
	private Zombie lesZombies[];
	private int nbrZombies;
	private int nbrLignes;
	private int nbrColonnes;
	private int ligneVictoire;
	private int niveauDifficulte;
	
	public Jeu(Carte carte, Joueur joueur, int nbrZombies, int niveauDifficulte)
	{
		this.carte = carte;
		this.joueur = joueur;
		this.nbrZombies = nbrZombies;
		this.lesZombies = new Zombie[nbrZombies];
		this.nbrLignes=carte.getNbrLignes();
		this.nbrColonnes=carte.getNbrColonnes();
		this.niveauDifficulte=niveauDifficulte;
		setup();
	}
	
	public void setup()
	{
		/**
		 * On place la case Victoire
		 */
		int derniereColonne=nbrColonnes-1;
		int randomLigne=0;
		//int random = (int)(Math.random() * (higher-lower)) + lower;
		// lower inclu higher exclu
		do
		{
			randomLigne = (int)(Math.random() * nbrLignes);
		}while(!carte.isCaseVide(randomLigne, derniereColonne));
		ligneVictoire=randomLigne;
		carte.setCase(randomLigne, derniereColonne, new Case(false, 'V'));
		
		/**
		 * On place le joueur
		 */
		
		int colonneMaxJoueur=nbrColonnes/4;
		int randomColonne;
		do
		{
			randomLigne = (int)(Math.random() * nbrLignes);
			randomColonne = (int) (Math.random() * colonneMaxJoueur);
		}while(!carte.isCaseVide(randomLigne, randomColonne));
		
		carte.setCase(randomLigne, randomColonne, new Case(false, 'J'));
		joueur.setLigneColonne(randomLigne, randomColonne);
		
		/**
		 * On place les zombies
		 */
		
		for(int i=0;i<nbrZombies;i++)
		{
			do
			{
				randomLigne = (int)(Math.random() * nbrLignes);
				randomColonne = (int) (Math.random() * nbrColonnes);
			}while(!carte.isCaseVide(randomLigne, randomColonne) || ( Math.abs(randomLigne-joueur.getLigne())+Math.abs(randomColonne-joueur.getColonne()) )< nbrLignes*nbrColonnes/100.0);
			carte.setCase(randomLigne, randomColonne, new Case(false, 'Z'));
			lesZombies[i]=new Zombie(randomLigne, randomColonne);
		}
	}
	
	public boolean unTour()
	{
		System.out.println("\n\n\n\n\n\n"+carte.toString());
		/**
		 * Déplacement du joueur
		 */
		
		boolean directionValide=true;
		System.out.println("\n\nTapez la direcion vers laquelle vous voulez déplacer le joueur puis tapez sur \"Entrée\".");
		System.out.println("Haut : z, Gauche : q, Bas : s et Droite : d");
		Scanner sc = new Scanner(System.in);
		String direction;
		do
		{
			directionValide=true;
			direction = sc.next();
			System.out.println();
			// On vérifie que l'utilisateur a bien écrit z ou q ou s ou d
			if(!direction.equals("z") && !direction.equals("q") && !direction.equals("s") && !direction.equals("d"))
			{
				System.out.println("Cette direction n'est pas valide, veuillez écrire z ou q ou s ou d.\n");
				directionValide=false;
			}
			else
			{
				// pour la future position du joueur
				// on vérifie qu'il va aller dans une case vide
				// sinon on passe directionValide à faux
				if(direction.equals("z"))
				{
					if(joueur.getLigne()-1 >=0 && carte.isCaseVide(joueur.getLigne()-1, joueur.getColonne()))
					{
						// on déplace le joueur
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(true));
						joueur.setLigneColonne(joueur.getLigne()-1, joueur.getColonne());
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(false, 'J'));
					}
					else
					{
						directionValide=false;
						System.out.println("Un obstacle vous empêche d'aller dans cette direction. Essayez-en une autre.\n");
					}
				}
				else if(direction.equals("q"))
				{
					if(joueur.getColonne()-1 >=0 && carte.isCaseVide(joueur.getLigne(), joueur.getColonne()-1))
					{
						// on déplace le joueur
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(true));
						joueur.setLigneColonne(joueur.getLigne(), joueur.getColonne()-1);
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(false, 'J'));
					}
					else
					{
						directionValide=false;
						System.out.println("Un obstacle vous empêche d'aller dans cette direction. Essayez-en une autre.\n");
					}
				}
				else if(direction.equals("s"))
				{
					if(joueur.getLigne()+1 < carte.getNbrLignes() && carte.isCaseVide(joueur.getLigne()+1, joueur.getColonne()))
					{
						// on déplace le joueur
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(true));
						joueur.setLigneColonne(joueur.getLigne()+1, joueur.getColonne());
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(false, 'J'));
					}
					else
					{
						directionValide=false;
						System.out.println("Un obstacle vous empêche d'aller dans cette direction. Essayez-en une autre.\n");
					}
				}
				else
				{
					if(joueur.getColonne()+1 <carte.getNbrColonnes() && carte.isCaseVide(joueur.getLigne(), joueur.getColonne()+1))
					{
						// on déplace le joueur
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(true));
						joueur.setLigneColonne(joueur.getLigne(), joueur.getColonne()+1);
						carte.setCase(joueur.getLigne(), joueur.getColonne(), new Case(false, 'J'));
					}
					else
					{
						directionValide=false;
						System.out.println("Un obstacle vous empêche d'aller dans cette direction. Essayez-en une autre.\n");
					}
				}
			}
		}while(!directionValide);
		
		/**
		 * Si le joueur est à une case de la case Victoire, il a gagné sauf s'il est en diagonale
		 */
		if(Math.abs(joueur.getLigne()-ligneVictoire)<=1 && Math.abs(joueur.getColonne()-(nbrColonnes-1))<=1)
		{
			// si le joueur est au dessus
			if(ligneVictoire-joueur.getLigne()==1 && (nbrColonnes-1)==joueur.getColonne())
			{
				System.out.println(carte.toString());
				System.out.println("Félicitations ! Vous avez gagné !");
				return false;
			}
			// si le joueur est à gauche
			else if(ligneVictoire==joueur.getLigne() && (nbrColonnes-1)-joueur.getColonne()==1)
			{
				System.out.println(carte.toString());
				System.out.println("Félicitations ! Vous avez gagné !");
				return false;
			}
			// si le joueur est en bas
			else if(joueur.getLigne()-ligneVictoire==1 && (nbrColonnes-1)==joueur.getColonne())
			{
				System.out.println(carte.toString());
				System.out.println("Félicitations ! Vous avez gagné !");
				return false;
			}
		}
		
		/**
		 * Si le zombie est à une case du joueur il a perdu sauf s'il est en diagonale
		 */
		for(Zombie z:lesZombies)
		{
			if(Math.abs(joueur.getLigne()-z.getLigne())<=1 && Math.abs(joueur.getColonne()-z.getColonne())<=1)
			{
				// si le joueur est au dessus
				if(z.getLigne()-joueur.getLigne()==1 && z.getColonne()==joueur.getColonne())
				{
					System.out.println(carte.toString());
					System.out.println("GRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
				// si le joueur est à gauche
				else if(z.getLigne()==joueur.getLigne() && z.getColonne()-joueur.getColonne()==1)
				{
					System.out.println(carte.toString());
					System.out.println("GRHGRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
				// si le joueur est en bas
				else if(joueur.getLigne()-z.getLigne()==1 && z.getColonne()==joueur.getColonne())
				{
					System.out.println(carte.toString());
					System.out.println("GRHGRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
				// si le joueur est à droite
				else if(z.getLigne()==joueur.getLigne() && joueur.getColonne()-z.getColonne()==1)
				{
					System.out.println(carte.toString());
					System.out.println("GRHGRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
			}
		}
		
		
		/**
		 * Déplacement des zombies à l'aide de l'intelligence artificielle
		 */
		
		for(Zombie z:lesZombies)
		{
			char directionZombie=z.nextMove(carte,joueur,niveauDifficulte);
			if(directionZombie=='z')
			{
				carte.setCase(z.getLigne(), z.getColonne(), new Case(true));
				z.setLigneColonne(z.getLigne()-1, z.getColonne());
				carte.setCase(z.getLigne(), z.getColonne(), new Case(false,'Z'));
			}
			else if(directionZombie=='q')
			{
				carte.setCase(z.getLigne(), z.getColonne(), new Case(true));
				z.setLigneColonne(z.getLigne(), z.getColonne()-1);
				carte.setCase(z.getLigne(), z.getColonne(), new Case(false,'Z'));
			}
			else if(directionZombie=='s')
			{
				carte.setCase(z.getLigne(), z.getColonne(), new Case(true));
				z.setLigneColonne(z.getLigne()+1, z.getColonne());
				carte.setCase(z.getLigne(), z.getColonne(), new Case(false,'Z'));
			}
			else if(directionZombie=='d')
			{
				carte.setCase(z.getLigne(), z.getColonne(), new Case(true));
				z.setLigneColonne(z.getLigne(), z.getColonne()+1);
				carte.setCase(z.getLigne(), z.getColonne(), new Case(false,'Z'));
			}
			
			
			/**
			 * Si le zombie est à une case du joueur il a perdu sauf s'il est en diagonale
			 */
			
			if(Math.abs(joueur.getLigne()-z.getLigne())<=1 && Math.abs(joueur.getColonne()-z.getColonne())<=1)
			{
				// si le joueur est au dessus
				if(z.getLigne()-joueur.getLigne()==1 && z.getColonne()==joueur.getColonne())
				{
					System.out.println(carte.toString());
					System.out.println("GRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
				// si le joueur est à gauche
				else if(z.getLigne()==joueur.getLigne() && z.getColonne()-joueur.getColonne()==1)
				{
					System.out.println(carte.toString());
					System.out.println("GRHGRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
				// si le joueur est en bas
				else if(joueur.getLigne()-z.getLigne()==1 && z.getColonne()==joueur.getColonne())
				{
					System.out.println(carte.toString());
					System.out.println("GRHGRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
				// si le joueur est à droite
				else if(z.getLigne()==joueur.getLigne() && joueur.getColonne()-z.getColonne()==1)
				{
					System.out.println(carte.toString());
					System.out.println("GRHGRRHGRHGRHGRRHHGRHGRHGRHGRHGR... Je crois que vous venez de vous faire mordre.\nVous avez perdu.");
					return false;
				}
			}
		}
		return true;
	}
	
	public void jouer()
	{
		while(unTour());
	}
}
