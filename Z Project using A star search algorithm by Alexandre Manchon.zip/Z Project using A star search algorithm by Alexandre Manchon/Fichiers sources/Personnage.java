/**
 * Personnage.java
 * 
 * Un personnage est une entité mobile de l'environnement.
 * Un personnage possède donc un nom, des coordonnées et une initiale qui sera sa représentation sur la carte
 */

public class Personnage
{
	private String nom;
	private char initiale;
	private int ligne;
	private int colonne;
	
	public Personnage(String nom, char initiale)
	{
		this.nom = nom;
		this.initiale= '?';
		this.ligne = 0;
		this.colonne = 0;
	}
	
	public Personnage(String nom, char initiale, int ligne, int colonne)
	{
		this.nom = nom;
		this.initiale= initiale;
		this.ligne = ligne;
		this.colonne = colonne;
	}

	public String getNom()
	{
		return nom;
	}

	public void setNom(String nom)
	{
		this.nom = nom;
	}

	public char getInitiale()
	{
		return initiale;
	}

	public void setInitiale(char initiale)
	{
		this.initiale = initiale;
	}

	public int getLigne()
	{
		return ligne;
	}

	public void setLigne(int ligne)
	{
		this.ligne = ligne;
	}

	public int getColonne()
	{
		return colonne;
	}

	public void setColonne(int colonne)
	{
		this.colonne = colonne;
	}
	
	public void setLigneColonne(int ligne, int colonne)
	{
		this.ligne = ligne;
		this.colonne = colonne;
	}
}
