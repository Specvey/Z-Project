/**
 * IA1.java
 * 
 * L'IA de difficulté 1 ne dispose d'aucune intelligence artificielle
 * il n'y a pas d'algo de recherche car la direction est aléatoire.
 */

public class IA1 extends IntelligenceArtificielle
{

	public IA1(Carte carte, Joueur joueur, int ligneZombie, int colonneZombie)
	{
		super(carte,joueur,ligneZombie,colonneZombie);
	}
	
	public boolean algoRecherche()
	{
		return true;
	}
	
	public char rechercheDirection()
	{
		char direction=' ';
		int aleatoire; // 1 pour haut, 2 pour gauche, 3 pour bas et 4 pour droite
		boolean directionPossible;
		do
		{
			aleatoire=1+(int)(Math.random()*4);
			directionPossible=true;
			switch(aleatoire)
			{
				case 1:if(ligneZombie==0 || !carte.isCaseVide(ligneZombie-1,colonneZombie)) directionPossible=false;break;
				case 2:if(colonneZombie==0 || !carte.isCaseVide(ligneZombie,colonneZombie-1)) directionPossible=false;break;
				case 3:if(ligneZombie==nbrLignes-1 || !carte.isCaseVide(ligneZombie+1,colonneZombie)) directionPossible=false;break;
				default:if(colonneZombie==nbrColonnes-1 || !carte.isCaseVide(ligneZombie,colonneZombie+1)) directionPossible=false;break;
			}
		}while(!directionPossible);
		
		switch(aleatoire)
		{
			case 1:direction='z';break;
			case 2:direction='q';break;
			case 3:direction='s';break;
			default:direction='d';break;
		}
		return direction;
	}

	
}
