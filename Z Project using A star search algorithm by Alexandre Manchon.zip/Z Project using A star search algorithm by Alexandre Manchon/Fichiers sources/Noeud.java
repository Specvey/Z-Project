import java.util.ArrayList;

/**
 * Noeud.java
 * 
 * Un noeud correspond à une case de la carte
 * Il sera utile pour les graphes dans l'algorithme de recherche
 */

public class Noeud
{
	private int ligne;
	private int colonne;
	private ArrayList<Noeud> lesPeres;
	private ArrayList<Noeud> lesFils;
	private double partieHeuristique;
	private int profondeur;
	private double heuristique;
	
	public Noeud(int ligne, int colonne)
	{
		this.ligne = ligne;
		this.colonne = colonne;
		this.lesPeres=new ArrayList<Noeud>();
		this.lesFils=new ArrayList<Noeud>();
		this.partieHeuristique=-1;
		this.profondeur=-1;
		this.heuristique=-1;
	}

	public int getLigne()
	{
		return ligne;
	}

	public void setLigne(int ligne)
	{
		this.ligne = ligne;
	}
	
	public int getColonne()
	{
		return colonne;
	}

	public void setColonne(int colonne)
	{
		this.colonne = colonne;
	}

	public double getPartieHeuristique()
	{
		return partieHeuristique;
	}

	public void setPartieHeuristique(double partieHeuristique)
	{
		this.partieHeuristique = partieHeuristique;
		this.heuristique=this.partieHeuristique+this.profondeur;
	}
	
	public int getProfondeur()
	{
		return profondeur;
	}

	public void setProfondeur(int profondeur)
	{
		this.profondeur = profondeur;
		this.heuristique=this.partieHeuristique+this.profondeur;
	}
	
	public Double getHeuristique()
	{
		return heuristique;
	}
	
	public ArrayList<Noeud> getLesPeres()
	{
		return lesPeres;
	}

	public void setLesPeres(ArrayList<Noeud> lesPeres)
	{
		this.lesPeres = lesPeres;
	}

	public ArrayList<Noeud> getLesFils()
	{
		return lesFils;
	}

	public void setLesFils(ArrayList<Noeud> lesFils)
	{
		this.lesFils = lesFils;
	}
	
	/**
	 * On ajoute un père s'il n'existe pas déjà dans les pères
	 */
	public void addPere(Noeud n)
	{
		boolean existeDeja=false;
		for(Noeud noeudPere:lesPeres)
		{
			if(noeudPere==n)
			{
				existeDeja=true;
			}
		}
		if(!existeDeja)
		{
			this.lesPeres.add(n);
		}
	}
	
	/**
	 * On ajoute un fils s'il n'existe pas déjà dans les fils
	 */
	public void addFils(Noeud n)
	{
		boolean existeDeja=false;
		for(Noeud noeudFils:lesFils)
		{
			if(noeudFils==n)
			{
				existeDeja=true;
			}
		}
		if(!existeDeja)
		{
			this.lesFils.add(n);
		}
	}
	
	public String toString()
	{
		return "("+ligne+","+colonne+")  ("+partieHeuristique+"+"+profondeur+"="+heuristique+")";
	}
	
}
