/**
 * IA3.java
 * 
 * L'IA de difficulté 3 est une intelligence artificielle qui donne aux zombies la possibilité de voir sur tout le graphe
 * c'est-à-dire que les zombies se déplacent tout le temps en direction du joueur
 */

public class IA3 extends IntelligenceArtificielle
{
	public IA3(Carte carte, Joueur joueur, int ligneZombie, int colonneZombie)
	{
		super(carte,joueur,ligneZombie,colonneZombie);
	}
	
	public boolean algoRecherche()
	{
		int nouvelleProfondeur;
		double nouvellePartieH;
		ferme.clear();
		ouvert.clear();
		Noeud n=new Noeud(ligneZombie,colonneZombie);
		n.setProfondeur(0);
		n.setPartieHeuristique(calculPartieHeuristique(n));
		ouvert.add(n);
		while(!ouvert.isEmpty())
		{
			tri(ouvert);
			n=ouvert.get(0);
			ouvert.remove(0);
			ferme.add(n);
			
			/**
			 * On regarde si le noeud n est juste à côté du joueur
			 */
			if(n.getLigne()==joueur.getLigne())
			{
				if(n.getColonne()==joueur.getColonne()-1)
				{
					return true;
				}
				else if(n.getColonne()==joueur.getColonne()+1)
				{
					return true;
				}
			}
			else if(n.getColonne()==joueur.getColonne())
			{
				if(n.getLigne()==joueur.getLigne()-1)
				{
					return true;
				}
				else if(n.getLigne()==joueur.getLigne()+1)
				{
					return true;
				}
			}

			listerFils(n);
			
			/**
			 * sinon on continue
			 */
			for(Noeud noeudFils:n.getLesFils())
			{
				/**
				 * On affecte un pointeur de n' à n
				 * C-à-d que l'on place n dans les pères de n'
				 */
				noeudFils.addPere(n);
				nouvelleProfondeur=n.getProfondeur()+1;
				nouvellePartieH=calculPartieHeuristique(noeudFils);
				if(!ouvert.contains(noeudFils) && !ferme.contains(noeudFils))
				{
					noeudFils.setProfondeur(nouvelleProfondeur);
					noeudFils.setPartieHeuristique(nouvellePartieH);
					ouvert.add(noeudFils);
				}
				else
				{
					if(noeudFils.getPartieHeuristique()==-1 || noeudFils.getProfondeur()==-1 || nouvelleProfondeur+nouvellePartieH<noeudFils.getHeuristique())
					{
						noeudFils.setProfondeur(nouvelleProfondeur);
						noeudFils.setPartieHeuristique(nouvellePartieH);
						if(ferme.contains(noeudFils))
						{
							ferme.remove(noeudFils);
							ouvert.add(noeudFils);
						}
					}
				}
			}
		}
		return false;
	}
	
	/**
	 * Le meilleur résultat d'une heuristique est 0.
	 */
	
	/**
	 * l'heuristique :
		f(n)=profondeur(n)+h(n)
		profondeur(n) la longueur du chemin (distance) entre la racine et n
		h(n) est la partie heuristique, elle doit être la plus informée possible
	 */
	
	
	public double calculPartieHeuristique(Noeud n)
	{
		/**
		 * On regarde où on est placé par rapport au joueur
		 * 
		 * si le noeud ne doit regarder que dans une direction pour voir le joueur :
		 * 
		 * 	et qu'il y a un obstacle dans cette direction alors il y a peu de chance que ce soit un noeud intéressant
		 * 	Dans ce cas, on multiplie sa distance au joueur par 3.
		 * 
		 * si le noeud doit regarder dans deux directions pour voir le joueur :
		 * 
		 * 	et qu'il y a un obstacle dans chacune de ces directions alors il y a encore moins de chance que ce soit un noeud intéressant
		 * 	Dans ce cas, on multiplie sa distance au joueur par 4.
		 * 
		 * 	et qu'il y a un obstacle dans une direction parmi les deux alors le noeud peut tout de même être intéressant
		 * 	Dans ce cas, on multiplie sa distance au joueur par 2.
		 * 
		 * Dans tous les cas où il n'y a pas d'obstacle pour voir le joueur,
		 * on renvoie la distance séparant le noeud et le joueur sans malus de multiplication.
		 */
		
		// les coefficients
		int uneDirectionUnObstacle=3;
		int deuxDirectionsUnObstacle=2;
		int deuxDirectionsDeuxObstacles=4;
		
		int nombreObstacles=0;
		
		/**
		 * S'il n'y a qu'une direction
		 */
		
		// si le joueur et le noeud sont sur la même ligne
		if(joueur.getLigne()==n.getLigne())
		{
			// si le joueur est plus à gauche
			if(joueur.getColonne()<n.getColonne())
			{
				// on regarde si la case à gauche du noeud est vide ou non
				if(carte.getCase(n.getLigne(),n.getColonne()-1).getSymbole()!='#') return distanceJoueur(n);
				else return distanceJoueur(n)*uneDirectionUnObstacle;
			}
			// si le joueur est plus à droite
			else
			{
				// si la case à droite du noeud est vide
				if(carte.getCase(n.getLigne(),n.getColonne()+1).getSymbole()!='#') return distanceJoueur(n);
				else return distanceJoueur(n)*uneDirectionUnObstacle;
			}
		}
		// si le joueur et le noeud sont sur la même colonne
		else if(joueur.getColonne()==n.getColonne())
		{
			// si le joueur est plus en haut
			if(joueur.getLigne()<n.getLigne())
			{
				// on regarde si la case en haut du noeud est vide ou non
				if(carte.getCase(n.getLigne()-1,n.getColonne()).getSymbole()!='#') return distanceJoueur(n);
				else return distanceJoueur(n)*uneDirectionUnObstacle;
			}
			// si le joueur est plus en bas
			else
			{
				// on regarde si la case en bas du noeud est vide ou non
				if(carte.getCase(n.getLigne()+1,n.getColonne()).getSymbole()!='#') return distanceJoueur(n);
				else return distanceJoueur(n)*uneDirectionUnObstacle;
			}
		}
		
		/**
		 * S'il y a deux directions
		 */
		
		else
		{
			// si le joueur est vers le haut et la gauche
			if(joueur.getLigne()<n.getLigne() && joueur.getColonne()<n.getColonne())
			{
				if(carte.getCase(n.getLigne()-1,n.getColonne()).getSymbole()=='#') nombreObstacles++;
				if(carte.getCase(n.getLigne(),n.getColonne()-1).getSymbole()!='#') nombreObstacles++;
			}
			
			// si le joueur est vers le haut et la droite
			else if(joueur.getLigne()<n.getLigne() && joueur.getColonne()>n.getColonne())
			{
				if(carte.getCase(n.getLigne()-1,n.getColonne()).getSymbole()=='#') nombreObstacles++;
				if(carte.getCase(n.getLigne(),n.getColonne()+1).getSymbole()=='#') nombreObstacles++;
			}
			
			// si le joueur est vers le bas et la gauche
			else if(joueur.getLigne()>n.getLigne() && joueur.getColonne()<n.getColonne())
			{
				if(carte.getCase(n.getLigne()+1,n.getColonne()).getSymbole()=='#') nombreObstacles++;
				if(carte.getCase(n.getLigne(),n.getColonne()-1).getSymbole()=='#') nombreObstacles++;
			}
			
			// si le joueur est vers le bas et la droite
			else
			{
				if(carte.getCase(n.getLigne()+1,n.getColonne()).getSymbole()=='#') nombreObstacles++;
				if(carte.getCase(n.getLigne(),n.getColonne()+1).getSymbole()=='#') nombreObstacles++;
			}
			
			if(nombreObstacles==0) return distanceJoueur(n);
			else if (nombreObstacles==1) return distanceJoueur(n)*deuxDirectionsUnObstacle;
			else return distanceJoueur(n)*deuxDirectionsDeuxObstacles;
		}
	}
	
	public char rechercheDirection()
	{
		Noeud procheJoueur=ferme.get(ferme.size()-1);
		Noeud noeudSuivant=rechercheRacine(procheJoueur);
		if(noeudSuivant.getColonne()==colonneZombie)
		{
			if(noeudSuivant.getLigne()==ligneZombie-1)
			{
				return 'z';
			}
			else if(noeudSuivant.getLigne()==ligneZombie+1)
			{
				return 's';
			}
			else
			{
				System.out.println(noeudSuivant.toString());
				return ' ';
			}
		}
		else if(noeudSuivant.getLigne()==ligneZombie)
		{
			if(noeudSuivant.getColonne()==colonneZombie-1)
			{
				return 'q';
			}
			else if(noeudSuivant.getColonne()==colonneZombie+1)
			{
				return 'd';
			}
			else
			{
				System.out.println(noeudSuivant.toString());
				return ' ';
			}
		}
		System.out.println(noeudSuivant.toString());
		return ' ';
	}
	
	private Noeud rechercheRacine(Noeud n)
	{
		if (n.getProfondeur()!=1)
		{
			for(Noeud noeudPere:n.getLesPeres())
			{
				return rechercheRacine(noeudPere);
			}
		}
		return n;
	}
	
}
